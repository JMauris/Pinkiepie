@SuppressWarnings( "all" )
public class SuppressAllWarnings
{
  public static void main( String[] args )
  {
    java.util.ArrayList list1 = new java.util.ArrayList();
    list1.add( "SuppressWarnings" );

    java.util.ArrayList list2 = new java.util.ArrayList();
  }
}
