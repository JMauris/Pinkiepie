/* 1 */public class NullPointer {
/* 2 */  @SuppressWarnings("null") public static void main( String[] args ) {
/* 3 */    java.awt.Point p = null;
/* 4 */    String         s = null;
/* 5 */
/* 6 */    p.setLocation( 1, 2 );
/* 7 */    s.length();
/* 8 */  }
/* 9 */}
