import com.tutego.DatePrinter;

public class DatePrinterUser2 {
  public static void main( String[] args ) {
    DatePrinter.printCurrentDate(); // 05/31/11
  }
}
