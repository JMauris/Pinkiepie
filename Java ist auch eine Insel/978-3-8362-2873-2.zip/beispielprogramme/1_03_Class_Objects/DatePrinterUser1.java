public class DatePrinterUser1 {
  public static void main( String[] args ) {
    com.tutego.DatePrinter.printCurrentDate(); // 05/31/11
  }
}
