package com.tutego.insel.game.vk;

public class Chocolate implements Buyable {
  @Override public double price() {
    return 0.69;
  }
}
