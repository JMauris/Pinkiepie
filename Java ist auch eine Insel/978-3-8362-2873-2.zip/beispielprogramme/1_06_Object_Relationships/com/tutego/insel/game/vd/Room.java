package com.tutego.insel.game.vd;

public class Room extends GameObject {
  public int size;
}
