package com.tutego.insel.game.va;

public class Player {
  public Room room;
}
