package com.tutego.insel.game.vd;

class Playground {

  public static void main( String[] args ) {
    Room clinic = new Room();
    clinic.name = "Clinic";
    clinic.size = 120000;
    
    Player theDoc = new Player();
    theDoc.name = "Dr. Schuwibscho";
   }
}
