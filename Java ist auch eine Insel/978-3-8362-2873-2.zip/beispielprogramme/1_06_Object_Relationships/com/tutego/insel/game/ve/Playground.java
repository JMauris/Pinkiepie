package com.tutego.insel.game.ve;

class Playground {

  public static void main( String[] args ) {
    Room winterfield = new Room();
    winterfield.setName( "Winterfield" );
    winterfield.setSize( 2040000 );
    System.out.println( winterfield ); // Room[name=Winterfield, size=2040000]
  }
}
