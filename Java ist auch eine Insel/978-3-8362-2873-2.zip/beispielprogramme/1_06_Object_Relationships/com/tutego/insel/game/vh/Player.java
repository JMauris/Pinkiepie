package com.tutego.insel.game.vh;

public class Player extends GameObject { }
