package com.tutego.insel.game.vd;

public class Player extends GameObject { }
