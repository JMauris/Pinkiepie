package com.tutego.insel.game.vh;

public abstract class GameObject {
  public String name;
}
