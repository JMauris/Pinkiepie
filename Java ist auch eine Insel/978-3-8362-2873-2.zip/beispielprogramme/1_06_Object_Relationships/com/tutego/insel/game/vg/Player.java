package com.tutego.insel.game.vg;

public class Player extends GameObject {
//  @Override
//  public void setName( String name ) {
//    this.name = name;
//  }
}
