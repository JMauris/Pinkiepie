public class Alien {
  public String planet;
  public Alien( String planet ) { this.planet = planet; }
}
