class PlayerData {
  String name = "";
  String item = "";
}
