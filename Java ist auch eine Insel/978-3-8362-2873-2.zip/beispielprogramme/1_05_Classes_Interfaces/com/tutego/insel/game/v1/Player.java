package com.tutego.insel.game.v1;

class Player { }
