package com.tutego.insel.game.v6;

public class Player {

  public String name;
  public String item;

  public Player( String name ) {
    this.name = name;
  }

  public Player( String name, String item ) {
    this.name = name;
    this.item = item;
  }  
}