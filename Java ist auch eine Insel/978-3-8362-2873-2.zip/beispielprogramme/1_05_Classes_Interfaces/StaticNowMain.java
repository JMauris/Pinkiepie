class StaticNowMain {

  static {
    System.out.println( "Jetzt bin ich das Hauptprogramm" );

    System.exit( 0 );
  }
}
