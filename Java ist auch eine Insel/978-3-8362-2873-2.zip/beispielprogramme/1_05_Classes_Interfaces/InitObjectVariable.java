class InitObjectVariable {

  int j = 1;
  
  InitObjectVariable() { }

  InitObjectVariable( int j ) {
    this.j = j;
  }
  
  InitObjectVariable( int x, int y ) { }
}
