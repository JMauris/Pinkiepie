public class Pattern {

  private final String pattern;

  public Pattern( String pattern ) {
    this.pattern = pattern;
  }

  public String getPattern() {
    return pattern;
  }
}
