public class VarArgs {
  public static void main( String[] args ) {
    System.out.printf( "Was sagst du?%n" );
    System.out.printf( "%d Kanäle und überall nur %s.%n", 220, "Katzen" );
  }
}
