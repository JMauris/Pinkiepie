class Application {

  public static void main( String[] args ) {
    // Hier ist der Anfang unserer Programme
    // Jetzt ist hier Platz für unsere eigenen Anweisungen
    // Hier enden unsere Programme
  }
}
