public class WithoutComplain {
  @SuppressWarnings( "unused" )
  static void main( String[] args ) {
    http://www.tutego.com/
    System.out.print( "Da gibt's Java-Tipps und Tricks." );  }
}
