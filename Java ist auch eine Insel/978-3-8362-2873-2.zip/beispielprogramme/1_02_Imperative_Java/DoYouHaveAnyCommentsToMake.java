/*
 * Der Quellcode ist public domain.
 */
/**
 * @author Christian Ullenboom
 */
class DoYouHaveAnyCommentsToMake { // TODO: Umbennenen

  /*
   * Die main()-Methode wollen wir nicht.
   * - Steht sowieso nix drin
   * - Was soll schon darein?
   */

  //  public static void main( String[] args )
  //  {  
  //  }
}
