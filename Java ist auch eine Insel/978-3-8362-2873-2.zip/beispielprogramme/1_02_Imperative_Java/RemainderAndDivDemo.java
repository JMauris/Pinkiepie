class RemainderAndDivDemo {

  public static void main( String[] args ) {
    System.out.println( " 5 %  3 = " + ( 5 %  3) );   //  2
    System.out.println( " 5 /  3 = " + ( 5 /  3) );   //  1
    
    System.out.println( " 5 % -3 = " + ( 5 % -3) );   //  2
    System.out.println( " 5 / -3 = " + ( 5 / -3) );   // -1
    
    System.out.println( "-5 %  3 = " + (-5 %  3) );   // -2
    System.out.println( "-5 /  3 = " + (-5 /  3) );   // -1
    
    System.out.println( "-5 % -3 = " + (-5 % -3) );   // -2
    System.out.println( "-5 / -3 = " + (-5 / -3) );   //  1
  }
}