class FriendlyGreeterCaller {
  public static void main( String[] args ) {
    FriendlyGreeter.greet();
  }
}
