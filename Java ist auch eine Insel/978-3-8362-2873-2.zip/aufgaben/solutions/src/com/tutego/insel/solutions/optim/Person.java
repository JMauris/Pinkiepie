//package com.tutego.insel.solutions.optim;
//
//import org.apache.commons.lang.builder.ToStringBuilder;
//
//public class Person extends Object
//{
//  private String name;
//  private String vorname;
//  private int    alter;
//
//  public String toString()
//  {
//    return ToStringBuilder.reflectionToString( this );
//  }
//  
//  public static void main( String[] args )
//  {
//    new Person().toString();
//  }
//}
