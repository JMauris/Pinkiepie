package com.tutego.insel.solutions.lang;

public class Average {

  static double average( double n, double m ) {
    return (n + m) / 2;
  }

  public static void main( String[] args ) {
    System.out.println( average( 7.5, 3.75 ) );
  }
}