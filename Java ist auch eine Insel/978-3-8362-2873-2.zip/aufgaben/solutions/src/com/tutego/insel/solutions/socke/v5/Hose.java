package com.tutego.insel.solutions.socke.v5;

public class Hose extends Kleidung {

  Hose( String farbe ) {
    super( farbe );
  }

  Hose() {
    this( "schwarz" );
  }
}
