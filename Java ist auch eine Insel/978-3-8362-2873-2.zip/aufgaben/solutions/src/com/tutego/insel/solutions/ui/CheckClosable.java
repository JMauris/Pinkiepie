package com.tutego.insel.solutions.ui;

public class CheckClosable {
  public static void main( String[] args ) {
    new JClosingFrame().setVisible( true );
  }
}
