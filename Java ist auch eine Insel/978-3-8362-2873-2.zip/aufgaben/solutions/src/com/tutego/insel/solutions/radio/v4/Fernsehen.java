package com.tutego.insel.solutions.radio.v4;

class Fernsehen extends Konsumgeraet {
  int programm;
}
