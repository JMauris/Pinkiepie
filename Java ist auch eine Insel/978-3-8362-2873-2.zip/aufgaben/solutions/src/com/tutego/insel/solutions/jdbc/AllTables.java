package com.tutego.insel.solutions.jdbc;

import java.sql.*;

public class AllTables
{
  public static void main( String[] args ) throws SQLException
  {
    DatabaseUtility db = new DatabaseUtility();

    try ( Connection con = db.getConnection() ) {
  
      DatabaseMetaData dbmd = con.getMetaData();
      
      ResultSet rsTables = dbmd.getTables( null, null, null, new String[]{"TABLE"} );
      
      while ( rsTables.next() )
      {
        String tableCatalog = rsTables.getString( 1 );
        String tableSchema = rsTables.getString( 2 );
        String tableName = rsTables.getString( 3 );
      
        System.out.println( tableName );
        System.out.println( tableCatalog );
        System.out.println( tableSchema );
      
         // Spaltennamen holen
      
        rsTables.close();
        
        ResultSet rsColumns = dbmd.getColumns( null,null,tableName,null );
  
        while ( rsColumns.next() )
        {
          System.out.println( rsColumns.getString(4) );
        }

        rsColumns.close();
      }
    }
  }
}
