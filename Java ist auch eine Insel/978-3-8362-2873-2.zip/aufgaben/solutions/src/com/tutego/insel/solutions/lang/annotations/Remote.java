package com.tutego.insel.solutions.lang.annotations;

public @interface Remote {}


