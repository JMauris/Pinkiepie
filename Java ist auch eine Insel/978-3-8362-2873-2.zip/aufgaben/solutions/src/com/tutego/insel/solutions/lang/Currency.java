package com.tutego.insel.solutions.lang;

public enum Currency
{
  USD, EUR, XAG, XAU, XBA
}
