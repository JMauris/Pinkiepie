package com.tutego.insel.solutions.radio.v1;

public class Radio {
  int lautstärke = 0;
  boolean eingeschaltet = false;
}
