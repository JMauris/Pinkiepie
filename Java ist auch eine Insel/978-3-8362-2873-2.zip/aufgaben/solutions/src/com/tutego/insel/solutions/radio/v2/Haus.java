package com.tutego.insel.solutions.radio.v2;

public class Haus {
  public static void main( String[] args ) {
    Radio omisAltesRadio = new Radio();
    omisAltesRadio.an();
    omisAltesRadio.lauter();
    omisAltesRadio.lauter();
    System.out.println( omisAltesRadio.toString() );
    omisAltesRadio.aus();
  }
}