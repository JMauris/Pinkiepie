package com.tutego.insel.solutions.lang;

public class YearLoop {
  public static void main( String[] args ) {
    for ( int j = 1900; j < 2000; j += 10 )
      System.out.println( j );
  }
}