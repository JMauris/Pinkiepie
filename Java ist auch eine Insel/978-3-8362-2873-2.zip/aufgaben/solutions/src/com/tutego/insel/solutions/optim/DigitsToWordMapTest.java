//package com.tutego.insel.solutions.optim;
//
//import junit.framework.Assert;
//import junit.framework.TestCase;
//
//public class DigitsToWordMapTest extends TestCase
//{
//  public void testGet()
//  {
//    Assert.assertEquals( "zero", DigitsToWordMap.get( "0" ) );
//    Assert.assertEquals( "two", DigitsToWordMap.get( "2" ) );
//    Assert.assertEquals( "five", DigitsToWordMap.get( "5" ) );
//    Assert.assertEquals( "ten", DigitsToWordMap.get( "10" ) );
//
//// Assert.assertEquals( null, DigitsToWordMap.get("12") );
//// Assert.assertEquals( null, DigitsToWordMap.get("-12") );
//// Assert.assertEquals( null, DigitsToWordMap.get("112") );
//  }
//
//  public static void main( String[] args )
//  {
//    junit.textui.TestRunner.run( DigitsToWordMapTest.class );
//  }
//}
