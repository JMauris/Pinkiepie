package com.tutego.insel.solutions.lang.annotations;

public enum TransactionManagementType
{
  CONTAINER,
  BEAN
}
