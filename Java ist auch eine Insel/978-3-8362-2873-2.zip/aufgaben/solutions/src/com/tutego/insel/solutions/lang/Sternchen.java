package com.tutego.insel.solutions.lang;

public class Sternchen {

  public static void main( String[] args ) {
    int i = 0;
    int stern = 30;
  
    while ( i < stern ) {
      System.out.print( "*" );
      i++;
    }
  }
}