package com.tutego.insel.solutions.optim;
public interface BasicMBean
{
	public void setData(String data);

	public String getData();
	
	public void doIt();
}
