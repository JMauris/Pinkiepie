//package com.tutego.insel.solutions.optim;
//
//public final static String rechsb�ndig( int i, int len )
//{
//  String s = Integer.toString( i );
//
//  if ( s.length() > len )
//    return s.substring( 0, len );
//  else
//    if ( s.length() < len )
//      return "                                ".substring( 0, len - s.length() ).concat( s );
//    else
//      return s;
//}
