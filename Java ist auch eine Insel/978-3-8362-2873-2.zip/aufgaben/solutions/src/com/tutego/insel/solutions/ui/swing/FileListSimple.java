package com.tutego.insel.solutions.ui.swing;

import java.io.File;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JScrollPane;

public class FileListSimple extends JFrame {
  private static final long serialVersionUID = -5825179736639276129L;

  private JList<File> list;

  public FileListSimple() {
    list = new JList<>( getFiles( "c:/" ) );

    getContentPane().add( new JScrollPane( list ) );
  }

  private File[] getFiles( String filename ) {
    File path = new File( filename );
    File[] files = path.listFiles();

    return files;
  }

  public static void main( String[] args ) {
    JFrame f = new FileListSimple();
    f.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    f.pack();
    f.setVisible( true );
  }
}