package com.tutego.insel.solutions.lang;

public class Maximum {

  public static void main( String[] args ) {
    double g;
    double h;
    g = Math.sin( 0.1 );
    h = Math.cos( 0.8 );
    System.out.println( "Wert von g: " + g );
    System.out.println( "Wert von h: " + h );
    System.out.println( "Maximum: " + Math.max( g, h ) );
  }
}