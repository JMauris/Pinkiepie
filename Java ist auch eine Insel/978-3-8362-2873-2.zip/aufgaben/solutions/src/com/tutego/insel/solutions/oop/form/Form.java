package com.tutego.insel.solutions.oop.form;

public abstract class Form {

  protected double x, y;

  public abstract double fläche();
}
