package com.tutego.insel.solutions.radio.v7;

class Fernsehen extends Konsumgeraet {
  int programm;
}
